System.register(["./instantiated-8d66d401.js"],(function(t){"use strict";return{setters:[function(e){t("default",e.hj)}],execute:function(){}}}));
