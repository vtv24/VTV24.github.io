System.register("chunks:///_virtual/MyButton.ts",["./_rollupPluginModLoBabelHelpers.js","cc","./MethodManager.ts"],(function(t){"use strict";var e,n,o,r,i,s,a,c;return{setters:[function(t){e=t.applyDecoratedDescriptor,n=t.initializerDefineProperty},function(t){o=t.cclegacy,r=t.Button,i=t._decorator,s=t.Component},function(t){a=t.MethodManager,c=t.CC_LOG_DEBUG}],execute:function(){var l,u,h,p,g;o._RF.push({},"b806bLLqY9EnYJvh3XY/1+K","MyButton",void 0);const{ccclass:d,property:b}=i;t("Button",(l=d("Button"),u=b({type:r}),l((g=e((p=class extends s{constructor(...t){super(...t),n(this,"button",g,this)}start(){new a,jsb.bridge.onNative=(t,e)=>{c("Trigger event for "+t+" is "+a.instance.applyMethod(t,e))},this.registerAllScriptEvent()}backClickHanler(){jsb.bridge.sendToNative("onClick"),console.log("[haha] hih")}requestPermissionHanler(){jsb.bridge.sendToNative("onRequestLocation")}registerAllScriptEvent(){a.instance.addMethod("changeLightColor",(()=>{console.log("[haha] hih")}))}}).prototype,"button",[u],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),h=p))||h));o._RF.pop()}}}));

System.register("chunks:///_virtual/MethodManager.ts",["./_rollupPluginModLoBabelHelpers.js","cc"],(function(e){"use strict";var t,r;return{setters:[function(e){t=e.defineProperty},function(e){r=e.cclegacy}],execute:function(){e("CC_LOG_DEBUG",(function(...e){})),r._RF.push({},"cce66asLVFFs56BB5fC+mIM","MethodManager",void 0);class n{addMethod(e,t){return!this.methodMap.get(e)&&(this.methodMap.set(e,t),!0)}applyMethod(e,t){if(!this.methodMap.get(e))return!1;var r=this.methodMap.get(e);try{return null==r||r.call(null,t),!0}catch(e){return console.log("Function trigger error: "+e),!1}}removeMethod(e){return this.methodMap.delete(e)}constructor(){t(this,"methodMap",void 0),this.methodMap=new Map,n.instance=this}}e("MethodManager",n),t(n,"instance",new n),r._RF.pop()}}}));

System.register("chunks:///_virtual/main",["./MethodManager.ts","./MyButton.ts"],(function(){"use strict";return{setters:[null,null],execute:function(){}}}));

(function(r) {
  r('virtual:///prerequisite-imports/main', 'chunks:///_virtual/main'); 
})(function(mid, cid) {
    System.register(mid, [cid], function (_export, _context) {
    return {
        setters: [function(_m) {
            var _exportObj = {};

            for (var _key in _m) {
              if (_key !== "default" && _key !== "__esModule") _exportObj[_key] = _m[_key];
            }
      
            _export(_exportObj);
        }],
        execute: function () { }
    };
    });
});