System.register("chunks:///_virtual/MyButton.ts",["./_rollupPluginModLoBabelHelpers.js","cc","./MethodManager.ts"],(function(t){"use strict";var e,n,r,i,o,s,a,l,c;return{setters:[function(t){e=t.applyDecoratedDescriptor,n=t.initializerDefineProperty},function(t){r=t.cclegacy,i=t.Button,o=t.LabelComponent,s=t._decorator,a=t.Component},function(t){l=t.MethodManager,c=t.CC_LOG_DEBUG}],execute:function(){var u,p,b,g,d,f,_;r._RF.push({},"b806bLLqY9EnYJvh3XY/1+K","MyButton",void 0);const{ccclass:h,property:y}=s;t("Button",(u=h("Button"),p=y({type:i}),b=y(o),u((f=e((d=class extends a{constructor(...t){super(...t),n(this,"button",f,this),n(this,"label",_,this)}start(){new l,jsb.bridge.onNative=(t,e)=>{c("Trigger event for "+t+" is "+l.instance.applyMethod(t,e))},this.registerAllScriptEvent()}backClickHanler(){jsb.bridge.sendToNative("COCOS_MAX_API",JSON.stringify({func:"goBack"}))}requestPermissionHanler(){jsb.bridge.sendToNative("COCOS_MAX_API",JSON.stringify({func:"requestLocation"}))}registerAllScriptEvent(){l.instance.addMethod("COCOS_MAX_API",(t=>{console.log("COCOS_MAX_API: "+t),this.label.string=t}))}}).prototype,"button",[p],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),_=e(d.prototype,"label",[b],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),g=d))||g));r._RF.pop()}}}));

System.register("chunks:///_virtual/MethodManager.ts",["./_rollupPluginModLoBabelHelpers.js","cc"],(function(e){"use strict";var t,r;return{setters:[function(e){t=e.defineProperty},function(e){r=e.cclegacy}],execute:function(){e("CC_LOG_DEBUG",(function(...e){})),r._RF.push({},"cce66asLVFFs56BB5fC+mIM","MethodManager",void 0);class n{addMethod(e,t){return!this.methodMap.get(e)&&(this.methodMap.set(e,t),!0)}applyMethod(e,t){if(!this.methodMap.get(e))return!1;var r=this.methodMap.get(e);try{return null==r||r.call(null,t),!0}catch(e){return console.log("Function trigger error: "+e),!1}}removeMethod(e){return this.methodMap.delete(e)}constructor(){t(this,"methodMap",void 0),this.methodMap=new Map,n.instance=this}}e("MethodManager",n),t(n,"instance",new n),r._RF.pop()}}}));

System.register("chunks:///_virtual/main",["./MethodManager.ts","./MyButton.ts"],(function(){"use strict";return{setters:[null,null],execute:function(){}}}));

(function(r) {
  r('virtual:///prerequisite-imports/main', 'chunks:///_virtual/main'); 
})(function(mid, cid) {
    System.register(mid, [cid], function (_export, _context) {
    return {
        setters: [function(_m) {
            var _exportObj = {};

            for (var _key in _m) {
              if (_key !== "default" && _key !== "__esModule") _exportObj[_key] = _m[_key];
            }
      
            _export(_exportObj);
        }],
        execute: function () { }
    };
    });
});